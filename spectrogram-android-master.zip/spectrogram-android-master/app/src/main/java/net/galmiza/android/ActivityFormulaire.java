package net.galmiza.android;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import net.galmiza.android.spectrogram.R;

public class ActivityFormulaire extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulaire);
    }
}
